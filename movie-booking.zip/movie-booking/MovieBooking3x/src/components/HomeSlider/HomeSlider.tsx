// import React, { useRef, useState } from 'react';
// // Import Swiper React components
// import { Swiper, SwiperSlide } from 'swiper/react';

// // Import Swiper styles
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';

// import { Navigation, Pagination, Mousewheel, Keyboard } from 'swiper/modules';
// import Image from 'next/image';

// const width = window.innerWidth;
// const height = window.innerHeight;
// const HomeSlider = () => {

//     const [banners, setBanners] = useState([
//         {
//             imgUrl: 'https://assets-in.bmscdn.com/promotions/cms/creatives/1693561351496_motogpsepdesktop.jpg'
//         },
//         {
//             imgUrl: 'https://assets-in.bmscdn.com/promotions/cms/creatives/1693472198837_iccdesktop.jpg'
//         }
//     ])



//     return (
//         <Swiper
//             cssMode={true}
//             navigation={true}
//             pagination={true}
//             mousewheel={true}
//             keyboard={true}
//             modules={[Navigation, Pagination, Mousewheel, Keyboard]}
//             className="mySwiper"
//         >
//             {
//                 banners.map((banner, index) => {
//                     return (
//                         <SwiperSlide key={index}>
//                             <Image src={banner.imgUrl} alt="" width={width} height={height / 2}
//                                 style={{
//                                     objectFit: "cover"
//                                 }} />
//                         </SwiperSlide>
//                     )
//                 })
//             }
//         </Swiper>
//     )
// }

// export default HomeSlider



import React, { useRef, useState, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import { Navigation, Pagination, Mousewheel, Keyboard } from 'swiper/modules';
import Image from 'next/image';

const HomeSlider = () => {
  const [banners, setBanners] = useState([
    {
      imgUrl: 'https://assets-in.bmscdn.com/promotions/cms/creatives/1693561351496_motogpsepdesktop.jpg'
    },
    {
      imgUrl: 'https://assets-in.bmscdn.com/promotions/cms/creatives/1693472198837_iccdesktop.jpg'
    }
  ]);

  const [width, setWidth] = useState(0);

  useEffect(() => {
    setWidth(window.innerWidth);
  }, []);

  return (
    <Swiper
      cssMode={true}
      navigation={true}
      pagination={true}
      mousewheel={true}
      keyboard={true}
      modules={[Navigation, Pagination, Mousewheel, Keyboard]}
      className="mySwiper"
    >
      {banners.map((banner, index) => (
        <SwiperSlide key={index}>
          <div style={{ width: '100%', position: 'relative', paddingTop: '56.25%' }}>  {/* 16:9 aspect ratio */}
            <Image
              src={banner.imgUrl}
              alt=""
              layout='fill' 
              objectFit="cover"
            />
          </div>
        </SwiperSlide>
      ))}
    </Swiper>
  );
};

export default HomeSlider;
