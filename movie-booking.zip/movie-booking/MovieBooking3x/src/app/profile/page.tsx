"use client"
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ProfilePage.css'; // Import your CSS file
import useRouter from 'next/router';

const ProfilePage: React.FC = () => {
    const [bookings, setBookings] = useState<any[]>([]);
    const [user, setUser] = useState<any>(null);

    const getBookings = async () => {
        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_API}/movie/getuserbookings`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include'
            });
            const data = await response.json();
            if (data.ok) {
                console.log(data);
                setBookings(data.data);
            } else {
                console.log(data);
            }
        } catch (error) {
            console.error('Error fetching bookings:', error);
        }
    };

    const getUserData = async () => {
        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_API}/auth/getuser`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include'
            });
            const data = await response.json();
            if (data.ok) {
                console.log(data);
                setUser(data.data);
            } else {
                console.log(data);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    };

    useEffect(() => {
        getBookings();
        getUserData();
    }, []);

    const deleteBooking = async (id: any) => {
        try {
            await fetch(`${process.env.NEXT_PUBLIC_BACKEND_API}/movie/deleteuserbooking/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include'
            });
    
            const updatedBookings = bookings.filter(booking => booking._id !== id);
            setBookings(updatedBookings);
    
            // Refresh the window after successful deletion
            window.location.reload();
        } catch (error) {
            console.error('Error deleting booking:', error);
            // Refresh the window even if there's an error
            window.location.reload();
        }
    };
    
    return (
        <div className='profile'>
            <h1 className='head'>Profile</h1>
            <div className='user'>
                <h2>User Details</h2>
                <div className='details'>
                    <div className='detail'>
                        <h3>Name</h3>
                        <p>{user?.name}</p>
                    </div>
                    <div className='detail'>
                        <h3>Email</h3>
                        <p>{user?.email}</p>
                    </div>
                    <div className='detail'>
                        <h3>City</h3>
                        <p>{user?.city}</p>
                    </div>
                </div>
            </div>
            <div className='bookings'>
                <h2>Bookings</h2>
                <div className='details'>
                    {bookings
                        ?.filter(booking => booking !== null) // Filter out null values
                        .map((booking: any) => {
                            
                            return (
                                <div className='booking' key={booking._id}>
                                    <p>{booking._id}</p>
                                    <div className='detail'>
                                        <h3>Movie</h3>
                                        <p>{booking.movieId?.title || 'Movie title not available'}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Screen</h3>
                                        <p>{booking.screenId?.name}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Show Date</h3>
                                        <p>{booking.showDate}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Show Time</h3>
                                        <p>{booking.showTime}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Seats</h3>
                                        <p>{booking.seats.map((seat: any) => seat.seat_id).join(', ')}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Price</h3>
                                        <p>{booking.totalPrice}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Payment Type</h3>
                                        <p>{booking.paymentType}</p>
                                    </div>
                                    <div className='detail'>
                                        <h3>Payment Id</h3>
                                        <p>{booking.paymentId}</p>
                                    </div>
                                    <button onClick={() => deleteBooking(booking._id)}>Delete</button>
                                </div>
                            );
                        })}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
