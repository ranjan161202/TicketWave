/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['in.bmscdn.com','assets-in.bmscdn.com'], // Add the hostname(s) here
    },
}

module.exports = nextConfig
