"use client"
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Movie {
    _id: string;
    title: string;
    description: string;
    portraitImgUrl: string;
    landscapeImgUrl: string;
    rating: number;
    genre: string[];
    duration: number;
    cast: {
        celebType: string;
        celebName: string;
        celebRole: string;
        celebImage: string;
    }[];
    crew: {
        celebType: string;
        celebName: string;
        celebRole: string;
        celebImage: string;
    }[];
}

const AllMovies: React.FC = () => {
    const [movies, setMovies] = useState<Movie[]>([]);

    useEffect(() => {
        const fetchMovies = async () => {
            try {
                const response = await axios.get(`${process.env.NEXT_PUBLIC_BACKEND_API}/admin/allmovies`);
                console.log(response)
                setMovies(response.data.ok); // Accessing the 'data' property to get the array of movies
            } catch (error) {
                console.error('Error fetching movies:', error);
            }
        };

        fetchMovies();
    }, []);
    const handleDelete = async (id: string) => {
        try {
            console.log(id)
            await axios.delete(`${process.env.NEXT_PUBLIC_BACKEND_API}/admin/allmovies/${id}`);
            const updatedMovies = movies.filter(movie => movie._id !== id);
            setMovies(updatedMovies);
        } catch (error) {
            console.error('Error deleting movie:', error);
        }
    };

    return (
        <div>
            <h1>All Movies</h1>
            <div className="movie-list">
                {movies && movies.length > 0 && (
                    movies.map(movie => (
                        <div key={movie._id} className="movie-card">
                            <img src={movie.portraitImgUrl} alt={movie.title} className="movie-image" />
                            <div className="movie-details">
                                <h2>{movie.title}</h2>
                                <p>{movie.description}</p>
                                <p>Rating: {movie.rating}</p>
                                <p>Genre: {movie.genre.join(', ')}</p>
                                <p>Duration: {movie.duration} minutes</p>
                                <button onClick={() => handleDelete(movie._id)}>Delete</button>
                            </div>
                        </div>
                    ))
                )}
            </div>
            <style jsx>{`
                .movie-list {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 20px;
                }
                .movie-card {
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    overflow: hidden;
                }
                .movie-image {
                    width: 100%;
                    height: auto;
                }
                .movie-details {
                    padding: 20px;
                }
                button {
                    margin-top: 10px;
                    padding: 5px 10px;
                    background-color: #ff0000;
                    color: #fff;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }
                button:hover {
                    background-color: #cc0000;
                }
            `}</style>
        </div>
    );
};export default AllMovies;
