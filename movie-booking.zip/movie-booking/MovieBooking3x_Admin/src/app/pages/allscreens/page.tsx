"use client"
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Screen {
    _id: string;
    name: string;
    location: string;
}

const AllScreens: React.FC = () => {
    const [screens, setScreens] = useState<Screen[]>([]);

    useEffect(() => {
        const fetchScreens = async () => {
            try {
                const response = await axios.get(`${process.env.NEXT_PUBLIC_BACKEND_API}/movie/allscreens`);
                setScreens(response.data.screens); // Accessing the 'screens' property to get the array of screens
            } catch (error) {
                console.error('Error fetching screens:', error);
            }
        };

        fetchScreens();
    }, []);

    const handleDeleteScreen = async (id: string) => {
        try {
            await axios.delete(`${process.env.NEXT_PUBLIC_BACKEND_API}/movie/screens/${id}`);
            const updatedScreens = screens.filter(screen => screen._id !== id);
            setScreens(updatedScreens);
        } catch (error) {
            console.error('Error deleting screen:', error);
        }
    };

    return (
        <div>
            <h1>All Screens</h1>
            <div className="screen-list">
                {screens && screens.length > 0 && (
                    screens.map(screen => (
                        <div key={screen._id} className="screen-card">
                            <h2>{screen.name}</h2>
                            <p>Location: {screen.location}</p>
                            <button onClick={() => handleDeleteScreen(screen._id)}>Delete</button>
                        </div>
                    ))
                )}
            </div>
            <style jsx>{`
                .screen-list {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 20px;
                }
                .screen-card {
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    padding: 20px;
                }
                button {
                    margin-top: 10px;
                    padding: 5px 10px;
                    background-color: #ff0000;
                    color: #fff;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }
                button:hover {
                    background-color: #cc0000;
                }
            `}</style>
        </div>
    );
};

export default AllScreens;
