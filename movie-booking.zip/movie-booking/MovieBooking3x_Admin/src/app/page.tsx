import Image from 'next/image'

export default function Home() {
  return (
    <main className="main"> {/* External CSS still applies */}
      <h1 style={{ color: 'blue', textAlign: 'center', fontSize: '3rem' }}>Home page</h1> 
    </main>
  )
}
